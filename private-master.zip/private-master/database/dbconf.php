<?php
define('HOST_NAME','localhost');
define('HOST_USER','root');
define('HOST_PASSWORD','ankit@123');
define('DBNAME','gmail');
