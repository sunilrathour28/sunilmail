<div class="resetForm">
<form >
    <div class="passwordResult"></div>
    <h3>Change password</h3>
    <div class="form-group">
        <label>New password</label>
        <input type="password" id="newPass" class="form-control" placeholder="Enter new Password">
    </div>

    <div class="form-group">
        <label>Confirm password</label>
        <input type="password" id="cPass" class="form-control" placeholder="Enter Password again">
    </div>
    <button type="button" id="reset" class="btn btn-primary">Change password</button>
</form>
</div>